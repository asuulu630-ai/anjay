importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyAYh0-TtxUB2i7U1gUYta6izKezQKFRLWk",
  authDomain: "apk-ovt-35c2a.firebaseapp.com",
  projectId: "apk-ovt-35c2a",
  storageBucket: "apk-ovt-35c2a.firebasestorage.app",
  messagingSenderId: "28947633269",
  appId: "1:28947633269:web:2e165b7fc0f847bf71143c"
});

const messaging = firebase.messaging();

// Notifikasi saat app di background / tertutup
messaging.onBackgroundMessage((payload) => {
  const title = (payload.notification && payload.notification.title) || 'Pesan baru';
  const body = (payload.notification && payload.notification.body) || '';
  const options = {
    body,
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    tag: 'kyxis-chat',
    renotify: true,
    vibrate: [120, 60, 120],
    data: Object.assign({ url: '/' }, payload.data || {}),
    requireInteraction: false,
  };
  return self.registration.showNotification(title, options);
});

// Klik notifikasi -> buka/fokus ke app
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = (event.notification.data && event.notification.data.url) || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) {
          client.focus();
          if (client.navigate) {
            try { client.navigate(targetUrl); } catch (e) {}
          }
          return;
        }
      }
      if (clients.openWindow) return clients.openWindow(targetUrl);
    })
  );
});
