const admin = require('firebase-admin');

if (!admin.apps.length) {
  const projectId = process.env.FIREBASE_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  const privateKey = (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n');

  if (!projectId || !clientEmail || !privateKey) {
    console.error('Missing Firebase Admin env vars');
  } else {
    admin.initializeApp({
      credential: admin.credential.cert({
        projectId,
        clientEmail,
        privateKey,
      }),
    });
  }
}

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  if (!admin.apps.length) {
    res.status(500).json({ error: 'Firebase Admin belum dikonfigurasi (cek env Vercel)' });
    return;
  }

  const { token, title, body, data } = req.body || {};
  if (!token) {
    res.status(400).json({ error: 'token wajib diisi' });
    return;
  }

  try {
    const messageId = await admin.messaging().send({
      token,
      notification: {
        title: title || 'Pesan baru',
        body: body || '',
      },
      data: {
        ...(data || {}),
        click_action: '/',
      },
      webpush: {
        notification: {
          title: title || 'Pesan baru',
          body: body || '',
          icon: '/icon-192.png',
          badge: '/icon-192.png',
          tag: 'kyxis-chat',
          renotify: true,
          requireInteraction: false,
        },
        fcmOptions: {
          link: '/',
        },
        headers: {
          Urgency: 'high',
        },
      },
      android: {
        priority: 'high',
      },
    });

    res.status(200).json({ ok: true, messageId });
  } catch (e) {
    console.error('Gagal kirim notif:', e);
    const code = (e.errorInfo && e.errorInfo.code) || e.code || '';
    res.status(500).json({
      error: e.message,
      code,
      invalidToken: /registration-token-not-registered|invalid-registration-token/i.test(String(code) + e.message),
    });
  }
};
